rm(list=ls())
start.time <- Sys.time()

#library(compiler)
#enableJIT(3)
library(gdata)

source("Input.R")

write("Min theoretical variance...", file = "bestorchard.txt", varmin, append = FALSE, "\n")
write("*", file = "bestorchard.txt", append = TRUE, sep = " ")
write("*", file = "bestpairs.txt", append = FALSE, sep = " ")
write("*", file = "varmin.txt", append = FALSE, sep = " ")

for (iter in 1:NITER) {
cat("iter = ", iter, "\n")
penalty <- 0
  
source("Data.R")

if(choice == 0) { # systematické vyplňování
  for (i in 1:rows) {
    for (j in 1:columns) {
      if(orchard[i,j] == 0) {
        source("Evaluation.R") # vyplnění pozice nejlepším kandidátem
      }
    }
  }
} 

else { # náhodné vyplňování
  
  # 1. najít všechna volná místa ve schématu
  x <- array(c(0:0),dim=empty)
  y <- array(c(0:0),dim=empty)
  count <- 0 # počítadlo prázdných míst
  for (i in 1:rows) {
    for (j in 1:columns) {
      if(orchard[i,j] == 0) {
        count <- count + 1
        x[count] <- i # a zapsat x pozice do vektoru
        y[count] <- j # a zapsat y pozice do vektoru
      }
    }
  }
  
  # 2. znáhodnit zjištěná volná místa
  rx <- array(c(0:0),dim=empty)
  ry <- array(c(0:0),dim=empty)
  r <- sample(c(1:count), count) # náhodná řada čísel
  for(i in 1:count) { # znáhodnění řad a sloupců
   rx[i] <- x[r[i]] 
   ry[i] <- y[r[i]]
  }
  
  # 3. náhodné vyplňování
  for(t in 1:count) { # znáhodnění řad a sloupců
    i <- rx[t] # x-souřadnice náhodné pozice
    j <- ry[t] # y-souřadnice náhodné pozice
    source("Evaluation.R") # vyplnění pozice nejlepším kandidátem
  }
}  

if(printchoice < 1) {
  source("Output.R")
}

if(min < totalmin) {
  totalmin <- min
  bestorchard <- orchard
  print(bestorchard)
  bestpairs <- pairs
  cat("........................", "\n")
  cat("criterion = ", min, "\n")
  cat("variance:", var(upperTriangle(bestpairs, diag=FALSE))*((size-1)/size), "\n")
  if(printchoice == 1) {
  source("Output.R")
  }
}
gc()
}

cat("xxx BEST SOLUTION xxx", "\n")
cat("Min theoretical variance...", varmin, "\n")
cat("Best variance:", var(upperTriangle(bestpairs, diag=FALSE))*((size-1)/size), "\n")
end.time <- Sys.time()
time.taken <- end.time - start.time
cat("Computing time:", time.taken, "\n")
cat("Computing time/iteration:", time.taken/NITER, "\n")