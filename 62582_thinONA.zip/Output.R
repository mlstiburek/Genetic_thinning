write(iter, file = "bestorchard9.txt", append = TRUE, sep = " ")
write(var(upperTriangle(bestpairs, diag=FALSE))*((size-1)/size), file = "bestorchard9.txt", append = TRUE, sep = ", ")
write.table(bestorchard,file="bestorchard9.txt", append = TRUE,col.names=F,row.names=F,sep =" " )
write(iter, file = "bestpairs9.txt", append = TRUE, sep = " ")
write.table(bestpairs,file="bestpairs9.txt", append = TRUE,col.names=F,row.names=F,sep = " ")

write(min, file = "varmin9.txt", append = TRUE, sep = " ")
