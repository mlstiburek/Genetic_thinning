# vstup zadávaný uživatelem
NITER <- 10 # počet nezávislých iterací
weight <- 100 # váha přiřazená separaci ramet stejného klonu (0 = nulová váha)
set.seed(12345) # seed pro generátor náhodných čísel
choice <- 0 # systematické vyplňování = 0, náhodné vyplňování = 1
printchoice <- 1 # 1 tiskne výsledky nejlepších řešení, 0 tiskne všechny výsledky (do souborů)

# deklarace ostatních proměnných
totalmin <- 9999999999999
