# loop through the whole matrix and sum all pair-wise matches
pairs <- array(0:0, dim = c(NT,NT)) 
penalty <- 0

for (r in 1:rows) {
  for (c in 1:columns) {
     left = 0; right = 0; up = 0; down = 0
     leftup = 0; rightup = 0; leftdown = 0; rightdown = 0; 
     
     center <- orchard[r,c]

       if(c != 1) {left <- orchard[r,c-1]
         if(r != 1) leftup <- orchard[r-1,c-1]
         if(r != rows) leftdown <- orchard[r+1,c-1]
       }
         if(left == center) penalty = penalty + 1
         if(leftup == center) penalty = penalty + 1
         if(leftdown == center) penalty = penalty + 1
     
       if(c != columns) {right <- orchard[r,c+1]
         if(r != 1) rightup <- orchard[r-1,c+1]
         if(r != rows) rightdown <- orchard[r+1,c+1]
       }
         if(right == center) penalty = penalty + 1
         if(rightup == center) penalty = penalty + 1
         if(rightdown == center) penalty = penalty + 1
     
       if(r != 1) up <- orchard[r-1,c]
         if(up == center) penalty = penalty + 1
     
       if(r != rows) down <- orchard[r+1,c]
         if(down == center) penalty = penalty + 1

       if(leftup != 0) {
         pairs[center,leftup] <- pairs[center,leftup] + 1   
       }     
     
       if(rightup != 0) {
         pairs[center,rightup] <- pairs[center,rightup] + 1   
       }
       
       if(leftdown != 0) {
         pairs[center,leftdown] <- pairs[center,leftdown] + 1   
       }
       
       if(rightdown != 0) {
         pairs[center,rightdown] <- pairs[center,rightdown] + 1   
       }

       if(left != 0) {
       pairs[center,left] <- pairs[center,left] + 1
       }
     
       if(right != 0) {
       pairs[center,right] <- pairs[center,right] + 1
       }
     
       if(up != 0) {
       pairs[center,up] <- pairs[center,up] + 1
       }
     
       if(down != 0) {
       pairs[center,down] <- pairs[center,down] + 1
       }
  }
}

# remove reciprocals from the diagonal
diagonal <- diag(pairs)

for (z in 1:NT){
  if(diagonal[z] > 0) {
    diagonal[z] <- diagonal[z]/2
  }
}
diag(pairs) <- diagonal

penalty <- penalty/2
size <- (NT*NT-NT)/2 # size of the upper triangular matrix

#criterion <- var(pairs), přenásobujeme korekcí, protože počítáme rozptyl pro celou populaci, nikoliv sample
criterion <- var(upperTriangle(pairs, diag=FALSE))*((size-1)/size) + penalty*weight

# criterion <- 1 # this value would provide random schemes, unmark this and hide everything else