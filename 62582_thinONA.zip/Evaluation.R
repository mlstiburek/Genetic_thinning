NC <- (sum(trees > 0)) # number of trees not allocated

# sample randomly trees that are not allocated and store them in a vector
if(NC > 1) {
  candidates <- sample(trees[trees > 0], NC)
} else {
  candidates <- max(trees)
}
  
# now evaluate each candidate (one at a time)
min <- 99999999999
for (k in 1:NC) { 
  orchard[i,j] <- candidates[k]
  source("Neighbours.R") # we evaluate the candidate with direct neigbours
  if(criterion < min) { # we store data on the best solution so far
    min <- criterion
    best.tree <- candidates[k]
  }
}

# and pick the best tree
l <- 1
best <- 0

while(best == 0){   
  if(trees[l] == best.tree) {
    trees[l] <- 0
    orchard[i,j] <- best.tree
    best <- 1
  }
  l <- l + 1
}